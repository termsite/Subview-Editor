﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void fIleToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create a SaveFileDialog to ask the user where to save the file
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                // Allow the user to save with any extension
                saveFileDialog.Filter = "All files (*.*)|*.*";
                saveFileDialog.Title = "Save your file";

                // Show the dialog and get result
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Get the file path selected by the user
                    string filePath = saveFileDialog.FileName;

                    // Write the contents of the TextBox to the file
                    File.WriteAllText(filePath, richTextBox1.Text);
                }
            }
        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an OpenFileDialog to ask the user to select a file to open
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                // Allow the user to open any file
                openFileDialog.Filter = "All files (*.*)|*.*";
                openFileDialog.Title = "Open a file";

                // Show the dialog and get result
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Get the file path selected by the user
                    string filePath = openFileDialog.FileName;

                    // Read the contents of the file and display it in the TextBox
                    richTextBox1.Text = File.ReadAllText(filePath);
                }
            }
        }

        private void basicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The text to add
            string newText = "<<!DOCTYPE html>\r\n<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\r\n<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\r\n<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->\r\n<!--[if gt IE 8]>      <html class=\"no-js\"> <!--<![endif]-->\r\n<html>\r\n    <head>\r\n        <meta charset=\"utf-8\">\r\n        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n        <title></title>\r\n        <meta name=\"description\" content=\"\">\r\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n        <link rel=\"stylesheet\" href=\"\">\r\n    </head>\r\n    <body>\r\n        <!--[if lt IE 7]>\r\n            <p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"#\">upgrade your browser</a> to improve your experience.</p>\r\n        <![endif]-->\r\n        \r\n        <script src=\"\" async defer></script>\r\n    </body>\r\n</html>";

            // Append the new text to the TextBox
            richTextBox1.AppendText(newText + Environment.NewLine);
        }

        private void headerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The text to add
            string newText = "<<!DOCTYPE html>\r\n<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\r\n<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\r\n<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->\r\n<!--[if gt IE 8]>      <html class=\"no-js\"> <!--<![endif]-->\r\n<html>\r\n    <head>\r\n        <meta charset=\"utf-8\">\r\n        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n        <title></title>\r\n        <meta name=\"description\" content=\"\">\r\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n        <link rel=\"stylesheet\" href=\"\">\r\n    </head>\r\n    <body>\r\n        <h1 class=\"YourClass1\">Header</h1>\r\n        <!--[if lt IE 7]>\r\n            <p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"#\">upgrade your browser</a> to improve your experience.</p>\r\n        <![endif]-->\r\n        \r\n        <script src=\"\" async defer></script>\r\n    </body>\r\n</html>";

            // Append the new text to the TextBox
            richTextBox1.AppendText(newText + Environment.NewLine);
        }

        private void paragraphToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The text to add
            string newText = "<<!DOCTYPE html>\r\n<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\r\n<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\r\n<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->\r\n<!--[if gt IE 8]>      <html class=\"no-js\"> <!--<![endif]-->\r\n<html>\r\n    <head>\r\n        <meta charset=\"utf-8\">\r\n        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n        <title></title>\r\n        <meta name=\"description\" content=\"\">\r\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n        <link rel=\"stylesheet\" href=\"\">\r\n    </head>\r\n    <body>\r\n        <p class=\"YourClass1\">Paragraph</p>\r\n        <!--[if lt IE 7]>\r\n            <p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"#\">upgrade your browser</a> to improve your experience.</p>\r\n        <![endif]-->\r\n        \r\n        <script src=\"\" async defer></script>\r\n    </body>\r\n</html>";

            // Append the new text to the TextBox
            richTextBox1.AppendText(newText + Environment.NewLine);
        }

        private void headerParagraphToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The text to add
            string newText = "<<!DOCTYPE html>\r\n<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\r\n<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\r\n<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->\r\n<!--[if gt IE 8]>      <html class=\"no-js\"> <!--<![endif]-->\r\n<html>\r\n    <head>\r\n        <meta charset=\"utf-8\">\r\n        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n        <title></title>\r\n        <meta name=\"description\" content=\"\">\r\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n        <link rel=\"stylesheet\" href=\"\">\r\n    </head>\r\n    <body>\r\n        <h1 class=\"YourClass1\">Header</h1>\r\n        <br>\r\n        <p class=\"YourClass2\">Paragraph</p>\r\n        <!--[if lt IE 7]>\r\n            <p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"#\">upgrade your browser</a> to improve your experience.</p>\r\n        <![endif]-->\r\n        \r\n        <script src=\"\" async defer></script>\r\n    </body>\r\n</html>";

            // Append the new text to the TextBox
            richTextBox1.AppendText(newText + Environment.NewLine);
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void errorLoadingEditcsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void fontSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void bGColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Show the color dialog and check if the user selected a color
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                // Change the textBox's background color to the selected color
                richTextBox1.BackColor = colorDialog1.Color;
            }
        }

        private void formBGColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Show the color dialog and check if the user selected a color
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                // Change the form's background color to the selected color
                this.BackColor = colorDialog1.Color;
            }
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size + 2);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size + 5);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size + 10);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size + 20);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size - 2);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size - 5);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            // Get the current font
            Font currentFont = richTextBox1.Font;

            // Create a new font with a larger size
            Font newFont = new Font(currentFont.FontFamily, currentFont.Size - 10);

            // Set the new font to the text box
            richTextBox1.Font = newFont;
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            
        }

        private void discordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Specify the URL you want to navigate to
            string url = "https://discord.gg/C3SnVrsmZs";

            // Open the URL in the default web browser
            Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            });
        }

        private void youtubeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Specify the URL you want to navigate to
            string url = "https://www.youtube.com/channel/UCm96fG82Uq6m-tOK3yvAxjQ";

            // Open the URL in the default web browser
            Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            });
        }

        private void githubToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Specify the URL you want to navigate to
            string url = "https://www.example.com";

            // Open the URL in the default web browser
            Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            });
        }

        private void cSSBasicsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The text to add
            string newText = "html {\r\n\r\n}\r\n\r\n.YourClass1 {\r\n\r\n}\r\n\r\n.YourClass2 {\r\n    \r\n}";

            // Append the new text to the TextBox
            richTextBox1.AppendText(newText + Environment.NewLine);
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of the new form
            Form1 form2 = new Form1();

            // Show the new form
            form2.Show();
        }

        private void secretButtonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of the new form
            Form1 form2 = new Form1();
            Form1 form3 = new Form1();
            Form1 form4 = new Form1();
            Form1 form5 = new Form1();
            Form1 form6 = new Form1();
            Form1 form7 = new Form1();
            Form1 form8 = new Form1();
            Form1 form9 = new Form1();
            Form1 form10 = new Form1();
            Form1 form11 = new Form1();
            Form1 form12 = new Form1();
            Form1 form13 = new Form1();
            Form1 form14 = new Form1();
            Form1 form15 = new Form1();
            Form1 form16 = new Form1();
            Form1 form17 = new Form1();
            Form1 form18 = new Form1();
            Form1 form19 = new Form1();
            Form1 form20 = new Form1();
            Form1 form21 = new Form1();

            // Show the new form
            form2.Show();
            form3.Show();
            form4.Show();
            form5.Show();
            form6.Show();
            form7.Show();
            form8.Show();
            form9.Show();
            form10.Show();
            form11.Show();
            form12.Show();
            form13.Show();
            form14.Show();
            form15.Show();
            form16.Show();
            form17.Show();
            form18.Show();
            form19.Show();
            form20.Show();
            form21.Show();

        }

        private void versionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
